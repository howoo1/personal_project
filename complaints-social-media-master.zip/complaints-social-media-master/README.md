# Complaints on Social Media

Research on identifying complaints in tweets.

Paper: http://www.preotiuc.ro/papers/complaints19acl.pdf

Data: complaints-data.csv

Code: To be uploaded soon

Citation:

```
@inproceedings{complaints2019acl,
  title={{Automatically Identifying Complaints in Social Media}},
  author={Preo\c{t}iuc-Pietro, Daniel and G\u{a}man, Mihaela and Aletras, Nikolaos},
  booktitle={Proceedings of the 57th Annual Meeting of the Association for Computational Linguistics},
  series={ACL},
  year={2019}
}
```
